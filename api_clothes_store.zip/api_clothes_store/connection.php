<?php
$serverHost = "localhost";
$user = "root";
$password = "";
$database = "clothes_app";

$connectNow = new mysqli($serverHost, $user, $password, $database);
//the above just connects to my database