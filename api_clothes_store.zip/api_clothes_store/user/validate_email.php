<?php
header("Access-Control-Allow-Origin: *");

include "../connection.php";

$userEmail = $_POST['user_email'];

$sqlQuery = "SELECT * FROM users_table WHERE user_email='$userEmail'"; //searches the database to see if the email already exists or not(gets the email)

$resultOfQuery = $connectNow->query($sqlQuery);//takes the sql query and runs it against the connected database

if($resultOfQuery->num_rows > 0)// if the email is there
{

    echo json_encode(array("emailFound"=>true));// if the result from the query is greater than 0 then that means the email is there

}
else
{
    echo json_encode(array("emailFound"=>false));
}